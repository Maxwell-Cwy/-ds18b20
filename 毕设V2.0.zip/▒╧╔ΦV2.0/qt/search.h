#ifndef SEARCH_H
#define SEARCH_H

#include <QWidget>
#include <QFileDialog>
#include <QFile>
#include<QTextStream>
#include<QDateTime>
#include<QTimer>
#include <QSerialPort>

#include<QSqlQuery>
#include<QSqlError>
#include<QSqlDatabase>
#include<QSqlRecord>
#include <QSqlTableModel>
#include <QTableView>

namespace Ui {
class Search;
}

class Search : public QWidget
{
    Q_OBJECT

public:
    explicit Search(QWidget *parent = nullptr);
    ~Search();
    void renew();
signals:
    void back();

private slots:

    void return_menu();

private:
    Ui::Search *ui;

    QSerialPort *serialPort;
    QSqlDatabase db3;
    QSqlTableModel *model3;
    QTableView *view3;
    QPushButton *returnButton;

public slots:

};

#endif //
