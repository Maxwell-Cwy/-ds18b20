#ifndef DBVIEW_H
#define DBVIEW_H


class dbview
{
public:
    dbview();
};

#endif // DBVIEW_H
