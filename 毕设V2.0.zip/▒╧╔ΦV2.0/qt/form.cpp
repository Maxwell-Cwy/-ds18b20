﻿#include "form.h"
#include "ui_form.h"
#include "widget.h"
#include "ui_widget.h"
#include<QPushButton>
#include<QDebug>
#include<QTableWidget>
#include<QTableWidgetItem>
#include<QStringList>
#include<QMessageBox>
#include <QTableView>
#include<QSqlQuery>
#include<QSqlError>
#include<QSqlDatabase>
#include<QSqlRecord>

#include <QMessageBox>
#include <QFile>
#include <QChartView>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonParseError>
#include <QJsonDocument>
#include <QSerialPort>
#include <QSqlTableModel>
#include <QDateTime>


Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{

    ui->setupUi(this);
    //this->resize(800, 480);
    serialPort = new QSerialPort(this);
    this->firmware = "RPMsg_UART_ADC_CM4.elf";

    qDebug()<<firmware<<endl;
    maxSize = 51;
    maxX=5000;
    maxY=100;

    lineSeries = new QLineSeries();
    chart = new QChart();

    axisY = new QValueAxis();
    axisX = new QValueAxis();


    chart->legend()->hide();
    chart->setTitle("实时温度数据");
    chart->addSeries(lineSeries);

    axisY->setLabelFormat("%i");
    axisY->setTitleText("温度/摄氏度");
    chart->addAxis(axisY, Qt::AlignLeft);
    axisY->setRange(0, maxY);
    lineSeries->attachAxis(axisY);

    axisX->setLabelFormat("%i");
    axisX->setTitleText("时间/ms");
    chart->addAxis(axisX, Qt::AlignBottom);
    axisX->setRange(0, maxX);
    lineSeries->attachAxis(axisX);

    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    #if __arm__
        loadFirmwareAndOpenSerial();
    #endif

    connect(serialPort, SIGNAL(readyRead()),
                 this, SLOT(serialPortReadyRead()));

    connectDB();
    qDebug()<<"test3"<<endl;

}


Form::~Form()
{
    delete ui;
}


void Form::on_pushButton_clicked()//menu
{
    emit this->back();
}



void Form::on_pushButton_2_clicked()
{
    qDebug()<<"switch"<<endl;
    QByteArray data("001");
    // 向串口写入数据
    qint64 bytesWritten = serialPort->write(data);

    if (bytesWritten == -1) {
         qWarning() << "Failed to write to port:" << serialPort->errorString();
     } else {
         qDebug() << "Bytes written:" << bytesWritten;
     }
}

void Form::serialPortReadyRead(){
    QString info;
    int xSpace;
    double T;
    int N;
    QString I;
    QSqlQuery query(db);


    qDebug()<<"start"<<endl;

    QByteArray buf = serialPort->readAll();
    QJsonParseError jsonError;
    double Tmp;

    QJsonDocument jsonDoc(QJsonDocument::fromJson(buf, &jsonError));

    if(jsonError.error != QJsonParseError::NoError){
            qDebug() << "json error!" << jsonError.errorString();
            return;
    }

    QJsonObject rootObj = jsonDoc.object();

    QStringList keys = rootObj.keys();

    for(int i = 0; i < keys.size(); i++)
    {
        qDebug() << "key" << i << " is:" << keys.at(i);
    }

    if(rootObj.contains("temp"))
     {
        QJsonObject subObj = rootObj.value("temp").toObject();
        qDebug() << "T is" << subObj.value("T").toDouble();
        qDebug() << "N is:" << subObj.value("N").toInt();
        qDebug() << "I is:" << subObj.value("I").toString();

        T=subObj.value("T").toDouble();
        N=subObj.value("N").toInt();
        I=subObj.value("I").toString();

        QString Ns=QString::number(N);
        QString Ts=QString::number(T);

        ui->label->setText("数量:"+ Ns);
        ui->label_2->setText("id:"+ subObj.value("I").toString());
        ui->label_3->setText("温度:" + Ts);

        insertData(I,Ts);

        Tmp=subObj.value("T").toDouble();
        data.append(Tmp);

        while (data.size() > maxSize) {
            data.removeFirst();
        }

        lineSeries->clear();
        xSpace = maxX / (maxSize - 1);

        for (int i = 0; i < data.size(); ++i) {
            lineSeries->append(xSpace * i, data.at(i));
        }

     }

}

void Form::loadFirmwareAndOpenSerial()
{

    QFile file("/dev/ttyRPMSG0");

    if (!file.exists()) {
        system("cd /lib/firmware");
        qDebug()<<"test2"<<endl;
        QString fw = tr("echo %1 > /sys/class/remoteproc/remoteproc0/firmware").arg(firmware);
        system(fw.toLatin1().data());
        system("echo start > /sys/class/remoteproc/remoteproc0/state");
        system("echo start > /dev/ttyRPMSG0");
        system("sleep 1");
    }

    serialPort->setPortName("/dev/ttyRPMSG0");
    serialPort->setBaudRate(115200);
    serialPort->setDataBits(QSerialPort::Data8);
    serialPort->setParity(QSerialPort::NoParity);
    serialPort->setStopBits(QSerialPort::OneStop);
    serialPort->setFlowControl(QSerialPort::NoFlowControl);

    if (!serialPort->open(QIODevice::ReadWrite)) {
        QMessageBox::about(NULL, "错误",
                           "串口无法打开！可能串口已经被占用或固件未正确加载！");

    }
    qDebug()<<"test232 "<<endl;

}

void Form::connectDB(){

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("temp");

    if (!db.open()){
       qDebug()<<"连接数据库错误"<<db.lastError()<<endl;
    }
    else{
       qDebug()<<"连接数据库成功"<<endl;
    }

    QSqlQuery query(db);

    query.exec("CREATE TABLE ds18b20 (" "id VARCHAR(15), " "temp VARCHAR(15), " "time VARCHAR(30))");

    if (!query.exec()) {
           qDebug() << "Error: Unable to create table -" << query.lastError().text();
    }

    model = new QSqlTableModel(this, db);
    model->setTable("ds18b20");
    model->setEditStrategy(QSqlTableModel::OnFieldChange);//
    model->select();



}

void Form::insertData(QString id,QString temp){

    QDateTime currentDateTime = QDateTime::currentDateTime();
    int row = model->rowCount();
    QString time = currentDateTime.toString("yyyy-MM-dd HH:mm:ss");
    qDebug()<<"row:"<<row<<endl;
    qDebug()<<"time:"<<time <<endl;

    /*
    model->insertRow(row);
    model->setData(model->index(row, 0),id); // 设置第一列的数据
    model->setData(model->index(row, 1), temp);    // 设置第二列的数据
    */

    QSqlQuery query(db);

    /*
    if (!query.exec("DROP TABLE IF EXISTS ds18b20")) {
            qDebug() << "Error: Unable to drop table -" << query.lastError().text();
    }*/

    query.prepare("INSERT INTO ds18b20 (id, temp,time) VALUES (:id, :temp, :time)");
    query.bindValue(":id", id);
    query.bindValue(":temp", temp);
    query.bindValue(":time", time);


    if (!query.exec()) {
        qDebug() << "Error: Unable to insert data -" << query.lastError().text();
     }
}

void Form::on_pushButton_3_clicked()//clear
{
    QSqlQuery query(db);
    if (!query.exec("DROP TABLE IF EXISTS ds18b20")) {
        qDebug() << "Error: Unable to drop table -" << query.lastError().text();
    }

    if (!query.exec("CREATE TABLE ds18b20 ("
                    "id VARCHAR(15), "
                    "temp VARCHAR(15), "
                    "time VARCHAR(30))")) {
        qDebug() << "Error: Unable to recreate table -" << query.lastError().text();
    }

}
