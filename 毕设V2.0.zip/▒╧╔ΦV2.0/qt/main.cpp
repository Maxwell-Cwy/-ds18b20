#include "widget.h"
#include<QDebug>
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w(nullptr);
    w.show();
    qDebug()<<"tetst3"<<endl;
    return a.exec();
}
