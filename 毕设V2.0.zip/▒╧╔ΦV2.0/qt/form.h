#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QFileDialog>
#include <QFile>
#include<QTextStream>
#include<QDateTime>
#include<QTimer>
#include <QChartView>
#include <QLineSeries>
#include <QScatterSeries>
#include <QValueAxis>
#include <QSerialPort>

#include<QSqlQuery>
#include<QSqlError>
#include<QSqlDatabase>
#include<QSqlRecord>
#include <QSqlTableModel>


QT_CHARTS_USE_NAMESPACE

namespace Ui {
class Form;
}

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

    QSqlDatabase db;
    QSqlTableModel *model;

    void connectDB();
signals:
    void back();

private slots:


    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::Form *ui;
    QSerialPort *serialPort;
    QString firmware;
    QFile file;

    /* 数据最大个数 */
    int maxSize;

    /* x轴上的最大值 */
    int maxX;

    /* y轴上的最大值 */
    int maxY;

    /* y轴 */
    QValueAxis *axisY;

    /* x轴 */
    QValueAxis *axisX;

    /* QList int类型容器 */
    QList<int> data;

    /* QLineSeries对象（折线）*/
    QLineSeries *lineSeries;

    /* QChart图表 */
    QChart *chart;

    void loadFirmwareAndOpenSerial();
    void insertData(QString id,QString temp);
public slots:
    void serialPortReadyRead();

};

#endif // FORM_H
