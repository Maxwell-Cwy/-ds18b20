#ifndef WIDGET_H
#define WIDGET_H


#include <search.h>
#include <QWidget>
#include<form.h>
#include <QWidget>
#include <QSerialPort>
#include <QWidget>
#include <QPushButton>
#include <QFile>
#include <QChartView>
#include <QTableView>
#include <QLineSeries>
#include <QScatterSeries>
#include <QValueAxis>
#include <dbview.h>

#include<QSqlQuery>
#include<QSqlError>
#include<QSqlDatabase>
#include<QSqlRecord>
#include <QSqlTableModel>
#include "form.h"

QT_BEGIN_NAMESPACE

namespace Ui { class Widget; }

QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
     Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();
private:
    Ui::Widget *ui;
    Form f;
    Search s;
    QTableView *view;
    QSerialPort *serialPort;
};

#endif // WIDGET_H
