#include "widget.h"
#include "ui_widget.h"
#include <QSerialPort>
#include <QDebug>
#include <QPushButton>
#include <QMessageBox>
#include <QFile>
#include <QChartView>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonParseError>
#include <QJsonDocument>

#include <QTableView>
#include<QSqlQuery>
#include<QSqlError>
#include<QSqlDatabase>
#include<QSqlRecord>
#include <QHBoxLayout>
#include <QVBoxLayout>


Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->resize(800, 480);
    serialPort = new QSerialPort(this);

    serialPort->setPortName("/dev/ttyRPMSG0");
    serialPort->setBaudRate(115200);
    serialPort->setDataBits(QSerialPort::Data8);
    serialPort->setParity(QSerialPort::NoParity);
    serialPort->setStopBits(QSerialPort::OneStop);
    serialPort->setFlowControl(QSerialPort::NoFlowControl);

    connect(&f,&Form::back,[=](){
        f.hide();
        this->show();
    });

    connect(&s,&Search::back,[=](){
        s.hide();
        this->show();
    });


}


Widget::~Widget()
{
    delete ui;
}


void Widget::on_pushButton_clicked()//search
{
    s.renew();
    s.show();
    qDebug()<<"table "<<endl;

}


void Widget::on_pushButton_2_clicked()//show
{
    f.show();
    this->hide();
}

void Widget::on_pushButton_3_clicked()//quit
{
    qDebug()<<"quit"<<endl;
    QFile file("/dev/ttyRPMSG0");

    if (file.exists()) {
        if (serialPort->isOpen())
            serialPort->close();
        system("echo stop > /sys/class/remoteproc/remoteproc0/state");
        system("sleep 1");
    }
    this->close();
}



