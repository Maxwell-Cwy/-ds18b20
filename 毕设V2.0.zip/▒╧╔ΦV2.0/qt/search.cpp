#include "search.h"
#include "ui_search.h"
#include "widget.h"
#include "ui_widget.h"
#include<QPushButton>
#include<QSqlQuery>
#include<QDebug>
#include<QTableWidget>
#include<QTableWidgetItem>
#include<QStringList>
#include<QMessageBox>
#include <QSerialPort>

#include<QSqlError>
#include<QSqlDatabase>
#include<QSqlRecord>
#include <QTableView>
#include<QSqlQuery>
#include <QSqlTableModel>
#include <QHBoxLayout>
#include <QVBoxLayout>

Search::Search(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Search)
{
    //ui->setupUi(this);

    qDebug()<<"search test3"<<endl;

    db3 = QSqlDatabase::addDatabase("QSQLITE");
    db3.setDatabaseName("temp");

    if (!db3.open()){
       qDebug()<<"连接数据库错误"<<db3.lastError()<<endl;
    }
    else{
       qDebug()<<"连接数据库成功"<<endl;
    }

    model3 = new QSqlTableModel(this, db3);
    model3->setTable("ds18b20");
    model3->setEditStrategy(QSqlTableModel::OnFieldChange);//
    model3->select();

    returnButton = new QPushButton("返回主界面", this);
    view3 = new QTableView;
    view3->setModel(model3);

    //view3->resize(800, 480);
    this->resize(800, 480);
    view3->resizeColumnsToContents();  // 自动调整列宽

    QVBoxLayout *vLayout = new QVBoxLayout(this);
    vLayout->addWidget(view3);
    vLayout->addWidget(returnButton);

    view3->show();

    if (!db3.open()){
       qDebug()<<"连接数据库错误"<<db3.lastError()<<endl;
    }
    else{
       qDebug()<<"连接数据库成功"<<endl;
    }

    connect(returnButton, &QPushButton::clicked, this, &Search::return_menu);
}



Search::~Search()
{
    delete ui;
}



void Search::return_menu(){

    close();
    qDebug()<<"back"<<endl;
    emit this->back();

}

void Search::renew(){

    if (!db3.open()){
       qDebug()<<"连接数据库错误"<<db3.lastError()<<endl;
    }
    else{
       qDebug()<<"连接数据库成功"<<endl;
    }
}
