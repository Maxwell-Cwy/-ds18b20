#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QPushButton>
#include <QMessageBox>
#include <QFile>
#include <QChartView>

Widget::Widget(QWidget *parent, QString firmware)
    : QWidget(parent)
    , ui(new Ui::Widget)
{

    ui->setupUi(this);
    this->firmware = firmware;
    serialPort = new QSerialPort(this);

    this->resize(800, 480);
    maxSize = 51;
    //maxX = 5000;
    //maxY = 3300;
    maxX=5000;
    maxY=100;
    lineSeries = new QLineSeries();
    chart = new QChart();

    axisY = new QValueAxis();
    axisX = new QValueAxis();


    chart->legend()->hide();
    chart->setTitle("实时温度数据");
    chart->addSeries(lineSeries);

    axisY->setLabelFormat("%i");
    axisY->setTitleText("温度/摄氏度");
    chart->addAxis(axisY, Qt::AlignLeft);
    axisY->setRange(0, maxY);
    lineSeries->attachAxis(axisY);

    axisX->setLabelFormat("%i");
    axisX->setTitleText("时间/ms");
    chart->addAxis(axisX, Qt::AlignBottom);
    axisX->setRange(0, maxX);
    lineSeries->attachAxis(axisX);

    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);



//#if __arm__
    loadFirmwareAndOpenSerial();
//#endif

    connect(serialPort, SIGNAL(readyRead()),
                this, SLOT(serialPortReadyRead()));
    qDebug()<<"test3"<<endl;

}


Widget::~Widget()
{
    delete ui;
}

/*
void Widget::serialPortReadWrite(){
    qDebug()<<"test"<<endl;
    QByteArray data("1");
    // 向串口写入数据
    qint64 bytesWritten = serialPort->write(data);
    if (bytesWritten == -1) {
         qWarning() << "Failed to write to port:" << serialPort->errorString();
     } else {
         qDebug() << "Bytes written:" << bytesWritten;
     }
    qDebug()<<"test4"<<endl;

}
*/

void Widget::loadFirmwareAndOpenSerial()
{
    QFile file("/dev/ttyRPMSG0");
    if (!file.exists()) {
        system("cd /lib/firmware");
        //qDebug()<<"%s\r\n"<<firmware<<endl;
        QString fw = tr("echo %1 > /sys/class/remoteproc/remoteproc0/firmware").arg(firmware);
        system(fw.toLatin1().data());
        system("echo start > /sys/class/remoteproc/remoteproc0/state");
        system("echo start > /dev/ttyRPMSG0");
        system("sleep 1");
    }
    serialPort->setPortName("/dev/ttyRPMSG0");
    serialPort->setBaudRate(115200);
    serialPort->setDataBits(QSerialPort::Data8);
    serialPort->setParity(QSerialPort::NoParity);
    serialPort->setStopBits(QSerialPort::OneStop);
    serialPort->setFlowControl(QSerialPort::NoFlowControl);

    if (!serialPort->open(QIODevice::ReadWrite)) {
        QMessageBox::about(NULL, "错误",
                           "串口无法打开！可能串口已经被占用或固件未正确加载！");
    }
}


void Widget::serialPortReadyRead(){
    qDebug()<<"test3"<<endl;
    QByteArray buf = serialPort->readAll();
    static int state;
    float Tmp;
    int xSpace;
    bool ok;
    QString info= QString(buf);
    //int len=info.length();
    //qDebug()<<"len:"<<len<<endl;
   // qDebug()<<"info[0]:"<<info[0]<<endl;
    qDebug()<<"info:"<<info<<endl;
   //qDebug()<<"state:"<<state<<endl;
    Tmp = info.toFloat(&ok);
   //qDebug()<<"Tmp:"<<Tmp<<endl;
    if(info[0]=="N"){
        state=0;
    }
    else{
          if(info[0]=="I"){
                state=1;
                //qDebug()<<"test4"<<endl;
           }
           else{
                if(info[0]=="T"){
                    state=2;
                    //qDebug()<<"test5"<<endl;
                }
                else{
                    switch(state){
                        case 0:
                            ui->label->setText("num:"+ info);
                            break;

                        case 1:
                            ui->label_3->setText("id:"+ info);
                            break;

                        case 2:
                            ui->label_4->setText("temp:"+ info);


                            //intTmp=20;

                            data.append(Tmp);
                            while (data.size() > maxSize) {
                                data.removeFirst();
                            }

                            lineSeries->clear();
                            xSpace = maxX / (maxSize - 1);

                            for (int i = 0; i < data.size(); ++i) {
                                lineSeries->append(xSpace * i, data.at(i));
                            }
                            break;

                        default:
                            break;
                    }
                }
           }
    }

}


void Widget::on_pushButton_clicked()//search
{
    qDebug()<<"search"<<endl;
    QByteArray data("000");
    // 向串口写入数据
    qint64 bytesWritten = serialPort->write(data);
    if (bytesWritten == -1) {
         qWarning() << "Failed to write to port:" << serialPort->errorString();
     } else {
         qDebug() << "Bytes written:" << bytesWritten;
     }
}


void Widget::on_pushButton_2_clicked()//quit
{
    qDebug()<<"quit"<<endl;
    QFile file("/dev/ttyRPMSG0");
    if (file.exists()) {
        if (serialPort->isOpen())
            serialPort->close();
        system("echo stop > /sys/class/remoteproc/remoteproc0/state");
        system("sleep 1");
    }
    this->close();
}

void Widget::on_pushButton_3_clicked()//switch
{
    qDebug()<<"switch"<<endl;
    QByteArray data("001");
    // 向串口写入数据
    qint64 bytesWritten = serialPort->write(data);

    if (bytesWritten == -1) {
         qWarning() << "Failed to write to port:" << serialPort->errorString();
     } else {
         qDebug() << "Bytes written:" << bytesWritten;
     }
}
