#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSerialPort>
#include <QPushButton>
#include <QFile>
#include <QChartView>
#include <QLineSeries>
#include <QScatterSeries>
#include <QValueAxis>

QT_CHARTS_USE_NAMESPACE

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE



class Widget : public QWidget
{
    Q_OBJECT

public:
     Widget(QWidget *parent = nullptr, QString firmware = nullptr);
     ~Widget();

private:
    Ui::Widget *ui;
    QString firmware;
    QFile file;
    QSerialPort *serialPort;

    void loadFirmwareAndOpenSerial();

    /* 数据最大个数 */
    int maxSize;

    /* x轴上的最大值 */
    int maxX;

    /* y轴上的最大值 */
    int maxY;

    /* y轴 */
    QValueAxis *axisY;

    /* x轴 */
    QValueAxis *axisX;

    /* QList int类型容器 */
    QList<int> data;

    /* QLineSeries对象（折线）*/
    QLineSeries *lineSeries;

    /* QChart图表 */
    QChart *chart;

private slots:

    void on_pushButton_clicked();//search

    void on_pushButton_2_clicked();//switch

    void on_pushButton_3_clicked();//quit

public slots:
    /* 读取数据 */
    void serialPortReadyRead();


};
#endif // WIDGET_H
