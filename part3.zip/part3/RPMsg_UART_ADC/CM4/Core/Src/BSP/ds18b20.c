/**
 ****************************************************************************************************
 * @file        ds18b20.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2020-05-25
 * @brief       DS18B20数字温度传感器 驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 STM32MP1开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 * 修改说明
 * V1.0 20200525
 * 第一次发布
 *
 ****************************************************************************************************
 */

#include "Include/ds18b20.h"
#include "./Include/delay.h"

void ds18b20_mode_out(void);

/**
 * @brief       复位DS18B20
 * @param       data: 要写入的数据
 * @retval      无
 */
static void ds18b20_reset(void)
{
    DS18B20_DQ_OUT(0);  /* 主机主机拉低DQ,复位 */
    delay_us(750);      /* 拉低750us */
    DS18B20_DQ_OUT(1);  /* DQ=1, 主机释放复位 */
    delay_us(15);       /* 延迟15US */
}

/**
 * @brief       等待DS18B20的回应
 * @param       无
 * @retval      0, DS18B20正常
 *              1, DS18B20异常/不存在
 */
uint8_t ds18b20_check(void)
{
    uint8_t retry = 0;
    uint8_t rval = 0;

    while (DS18B20_DQ_IN && retry < 200)    		/* 读取DQ值，等待DQ变低, 等待200us */
    {
        retry++;
        delay_us(1);
    }

    if (retry >= 200) 													/* 当等待时间大于200us时，DS18B20异常 */
    {
        rval = 1;
    }
    else																				/* 当等待时间小于200us时，DS18B20正常 */
    {
        retry = 0;

        while (!DS18B20_DQ_IN && retry < 240)   /* 等待DQ变高, 等待240us */
        {
            retry++;
            delay_us(1);
        }

        if (retry >= 240) rval = 1;							/* 超过240us，则认为DS18B20异常 */
    }

    return rval;
}

/**
 * @brief       从DS18B20读取一个位
 * @param       无
 * @retval      读取到的位值: 0 / 1
 */
static uint8_t ds18b20_read_bit(void)
{
    uint8_t data = 0;		/* 读到的值默认为0 */
    DS18B20_DQ_OUT(0);	/* 主机将总线DQ拉低 */
    delay_us(5);				/* 延时2us */
    DS18B20_DQ_OUT(1);	/* 主机将总线DQ拉高，释放总线 */
    delay_us(12);				/* 延时12us，等主机读取 */

    if (DS18B20_DQ_IN)	/* 读到的值为1 */
    {
        data = 1;
        //printf("data:%d\r\n",data);
    }
	//else{
    	 //printf("data:%d\r\n",data);
    //}

    delay_us(50);			  /* 延时50us，因为整个读的时间至少为60us */
    return data;
}

/**
 * @brief       从DS18B20读取一个字节
 * @param       无
 * @retval      读到的数据
 */
static uint8_t ds18b20_read_byte(void)
{
    uint8_t i, b, data = 0;

    for (i = 0; i < 8; i++)			/* 一个字节8位，分8次 */
    {
        b = ds18b20_read_bit(); /* DS18B20先输出低位数据 ,高位数据后输出 */

        data |= b << i;         /* 填充data的每一位 */
    }

    return data;
}

/**
 * @brief       写一个字节到DS18B20
 * @param       data: 要写入的字节
 * @retval      无
 */

void ds18b20_write_bit(uint8_t bool){
	ds18b20_mode_out();
	if(bool){
		DS18B20_DQ_OUT(0);  /*  Write 1 */
		delay_us(2);
		DS18B20_DQ_OUT(1);
		delay_us(60);
	}
	else{
        DS18B20_DQ_OUT(0);  /*  Write 0 */
        delay_us(60);
        DS18B20_DQ_OUT(1);
        delay_us(2);
	}
}

static void ds18b20_write_byte(uint8_t data)
{
    uint8_t j;

    for (j = 1; j <= 8; j++)
    {
				/* 写 1 操作*/
        if (data & 0x01)
        {
            DS18B20_DQ_OUT(0);  /* 主机拉低DQ */
            delay_us(2);				/* 拉低2 us的时间 */
            DS18B20_DQ_OUT(1);	/* DQ=1, 主机释放DQ */
            delay_us(60);				/* 延时60us */
        }
				/*  写 0 操作*/
        else
        {
            DS18B20_DQ_OUT(0);  /* 主机拉低DQ */
            delay_us(60);				/* 拉低60 us的时间 */
            DS18B20_DQ_OUT(1);	/* DQ=1, 主机释放DQ */
            delay_us(2);				/* 延时2 us */
        }

        data >>= 1;             /* 右移,获取高一位数据 */
    }
}

/**
 * @brief       开始温度转换
 * @param       无
 * @retval      无
 */
static void ds18b20_start(void)
{
    ds18b20_reset();						/* 复位DS18B20 */
    ds18b20_check();						/* 等待DS18B20的回应 */
    ds18b20_write_byte(0xcc);   /*  跳过ROM */
    ds18b20_write_byte(0x44);   /*  开始温度转换 */
}

/**
 * @brief       初始化DS18B20的IO口 DQ 同时检测DS18B20的存在
 * @param       无
 * @retval      0, 正常
 *              1, 不存在/不正常
 */
uint8_t ds18b20_init(void)
{
    GPIO_InitTypeDef gpio_init_struct;

    DS18B20_DQ_GPIO_CLK_ENABLE();   /* 开启DQ引脚时钟 */

    gpio_init_struct.Pin = DS18B20_DQ_GPIO_PIN;
    gpio_init_struct.Mode = GPIO_MODE_OUTPUT_OD;            /* 开漏输出 */
    gpio_init_struct.Pull = GPIO_PULLUP;                    /* 上拉 */
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;     /* 高速 */
    HAL_GPIO_Init(DS18B20_DQ_GPIO_PORT, &gpio_init_struct); /* 初始化DS18B20_DQ引脚 */
    /* DS18B20_DQ引脚模式设置,开漏输出,上拉, 这样就不用再设置IO方向了, 开漏输出的时候(=1), 也可以读取外部信号的高低电平 */

    ds18b20_reset();
    return ds18b20_check();
}

/**
 * @brief       从DS18B20得到温度值(精度：0.1C)
 * @param       无
 * @retval      温度值 （-550~1250）
 *   @note      返回的温度值放大了10倍.
 *              实际使用的时候,要除以10才是实际温度.
 */
short ds18b20_get_temperature(void)
{
    uint8_t flag = 1;           /* 默认温度为正数 */
    uint8_t TL, TH;
    short temp;

    ds18b20_start();            /*  开始温度转换 */
    ds18b20_reset();						/* 复位DS18B20 */
    ds18b20_check();						/* 等待DS18B20应答 */
    ds18b20_write_byte(0xcc);   /*  跳过ROM */
    ds18b20_write_byte(0xbe);   /*  读缓存器 */

    TL = ds18b20_read_byte();   /*  获取温度低位值 LSB */
    TH = ds18b20_read_byte();   /*  获取温度高位值 MSB */

    if (TH > 7)			/* 判断温度正负 */
    {
        TH = ~TH;
        TL = ~TL;
				TL+=1;
        flag = 0;   /* 温度为负 */
    }

    temp = TH;      /* 获得高八位 */
    temp <<= 8;
    temp += TL;     /* 获得底八位 */
    temp = (double)temp * 0.625;    /* 转换 */

    if (flag == 0)			/* 如果温度为负数 */
    {
        temp = -temp;   /* 将温度转换成负温度 */
    }

    return temp;
}


void ds18b20_mode_out(void)//ds18b20输出模式配置
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.Pin = DS18B20_DQ_Pin;
	GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStructure.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(DS18B20_DQ_GPIO_Port, &GPIO_InitStructure);

}

void ds18b20_mode_ipu(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.Pin = DS18B20_DQ_Pin;
	GPIO_InitStructure.Mode = GPIO_MODE_INPUT;
	//GPIO_InitStructure.Pull=GPIO_PULLUP;
	HAL_GPIO_Init(DS18B20_DQ_GPIO_Port, &GPIO_InitStructure);
}


uint8_t ds18b20_read_2bit(void)//读二位 子程序
{
	uint8_t i;
	uint8_t data = 0;
	for (i = 2; i > 0; i--)
	{
		data = data << 1;
		ds18b20_mode_out();
		DS18B20_DQ_OUT(0);
		delay_us(2);
		DS18B20_DQ_OUT(1);
		ds18b20_mode_ipu();
		delay_us(12);
		if (DS18B20_DQ_IN)	data |= 0x01;
		delay_us(50);
	}
	return data;
}



// 自动搜索ROM
void ds18b20_search_rom(void)
{
	uint8_t k, L, chongtuwei, m, n, num;
	//uint8_t zhan[64+1];//按顺序保存冲突位的位号
	uint8_t zhan[MaxSensorNum-1]={0};
	uint8_t ss[64];//保存64个bit
	L = 0;
	num = 0;
	do
	{
		ds18b20_reset(); //注意：复位的延时不够
		delay_us(750); //480、720
		ds18b20_write_byte(0xf0);
		for (m = 0; m < 8; m++)//8 * 8 = 64bit ID
		{
			uint8_t s = 0;//用于缓存当前读到的字节位
			for (n = 0; n < 8; n++)//8bit
			{
				k = ds18b20_read_2bit();//读两位数据
				//printf("%d \n",k);
				k = k & 0x03;
				s >>= 1;//低位开始
				if (k == 0x01)//01读到的数据为0 写0 此位为0的器件响应
				{
					ds18b20_write_bit(0);
					ss[(m * 8 + n)] = 0;
				}
				else if (k == 0x02)//10读到的数据为1 写1 此位为1的器件响应
				{
					s = s | 0x80;
					ds18b20_write_bit(1);
					ss[(m * 8 + n)] = 1;
				}
				else if (k == 0x00)//读到的数据为00 有冲突位 判断冲突位
				{
					//如果冲突位大于栈顶写0 小于栈顶写以前数据 等于栈顶写1
					chongtuwei = m * 8 + n + 1;
					if (chongtuwei > zhan[L])
					{
						ds18b20_write_bit(0);
						ss[(m * 8 + n)] = 0;
						zhan[++L] = chongtuwei;//记录该新的冲突位
					}
					else if (chongtuwei < zhan[L])
					{
						s = s | ((ss[(m * 8 + n)] & 0x01) << 7);
						ds18b20_write_bit(ss[(m * 8 + n)]);
					}
					else if (chongtuwei == zhan[L])
					{
						s = s | 0x80;
						ds18b20_write_bit(1);
						ss[(m * 8 + n)] = 1;
						L = L - 1;
					 }
				}
				else
				{
					//没有搜索到
					break;
				}
			}
			DS18B20_ID[num][m] = s; // 保存搜索到的ID字节
		}
		num = num + 1;// 保存搜索到的个数
		//printf("num:%d \n",num);
	} while (zhan[L] != 0 && (num < MaxSensorNum));//测试完所有冲突位，或搜索到的个数大于最大数则退出
	DS18B20_SensorNum = num;
}

float ds18b20_get_temp_id(uint8_t* ID)
{
    //u8 flag;
	uint8_t j;//匹配的字节
	uint8_t TL, TH;
	short Temperature;
	float Temperature1;
	ds18b20_reset();
	ds18b20_check();
	ds18b20_write_byte(0xcc);// skip rom
	ds18b20_write_byte(0x44);// convert
	delay_ms(750);

	ds18b20_reset();
	ds18b20_check();
	//匹配ID，i为形参
	ds18b20_write_byte(0x55);
	for (j = 0; j < 8; j++)
	{
		ds18b20_write_byte(ID[j]);
	}
	//ds18b20_write_byte(0x44);// convert
	//delay_ms(100);
	ds18b20_write_byte(0xbe);// 读寄存器的值
	//delay_ms(10);
	TL = ds18b20_read_byte(); // LSB
	TH = ds18b20_read_byte(); // MSB
	printf("TL:%02x TH:%02x \r\n",TL,TH);
	if (TH & 0xfc)
	{
		//flag=1;
		Temperature = (TH << 8) | TL;
		Temperature1 = (~Temperature) + 1;
		Temperature1 *= 0.0625;
	//printf("T1:%d \n",(int)Temperature1);
	}
	else
	{
		//flag=0;
        Temperature1 = ((TH << 8) | TL)*0.0625;
	}
	//printf("T1:%.2f",Temperature1);
	return Temperature1;
}















