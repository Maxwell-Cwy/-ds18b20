#ifndef __DELAY_H
#define __DELAY_H
#include "stm32mp1xx.h"
#include "stm32mp1xx_hal.h"
#include "core_cm4.h"
void delay_init(uint16_t sysclk); /* 初始化延迟函数 */
void delay_ms(uint16_t nms);      /* 延时nms */
void delay_us(uint32_t nus);      /* 延时nus */


/**
 * SYS_SUPPORT_OS用于定义系统文件夹是否支持OS
 * 0,不支持OS
 * 1,支持OS
 */
#define SYS_SUPPORT_OS         0


#endif
