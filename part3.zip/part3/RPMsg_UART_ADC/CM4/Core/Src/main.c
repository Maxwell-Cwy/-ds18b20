/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "ipcc.h"
#include "openamp.h"
#include "usart.h"
#include "gpio.h"
#include "stdlib.h"
#include "cJSON.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
 #include "virt_uart.h"

//#include "./BSP/Include/led.h"
#include "./BSP/Include/delay.h"
#include "./BSP/Include/ds18b20.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
uint8_t BuffTx[100];
VIRT_UART_HandleTypeDef huart0;
__IO FlagStatus flag = RESET;

uint32_t adc_get_result_average(uint32_t ch, uint8_t times);

void VIRT_UART0_RxCpltCallback(VIRT_UART_HandleTypeDef *huart);

#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif

PUTCHAR_PROTOTYPE
{
    while ((USART3->ISR & 0X40) == 0);
    USART3->TDR = (uint8_t) ch;
    return ch;
}
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
extern unsigned char DS18B20_ID[MaxSensorNum][8];	// 存检测到的传感器DS18B20_ID的数组,前面的维数代表单根线传感器数量上限
extern unsigned char DS18B20_SensorNum;		// 检测到的传感器数量(从1开始，例如显示1代表1个，8代表8个)
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void PeriphCommonClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int state=0;
int main(void)
{
  /* USER CODE BEGIN 1 */
	//uint16_t adcx;

	int i,j;
	float temperature;
	cJSON *cjson_head=NULL;
	cJSON *cjson_temp=NULL;
	char *str=NULL;
	char buf[50];
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  if(IS_ENGINEERING_BOOT_MODE())
  {
    /* Configure the system clock */
    SystemClock_Config();
  }

  if(IS_ENGINEERING_BOOT_MODE())
  {
    /* Configure the peripherals common clocks */
    PeriphCommonClock_Config();
  }

  /* IPCC initialisation */
   MX_IPCC_Init();
  /* OpenAmp initialisation ---------------------------------*/
  MX_OPENAMP_Init(RPMSG_REMOTE, NULL);

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART3_UART_Init();
  MX_ADC1_Init();
  delay_init(209);

  while(ds18b20_init()){
	  printf("init error!\r\n");
	  delay_ms(1000);
  }


  /* USER CODE BEGIN 2 */
  printf("****** Start Initialize Virtual UART0 ******\r\n");
    if (VIRT_UART_Init(&huart0) != VIRT_UART_OK)
    {
  	  printf("****** VIRT_UART_Init UART0 failed. ******\r\n");
  	  Error_Handler();
     }

    if(VIRT_UART_RegisterCallback(&huart0, VIRT_UART_RXCPLT_CB_ID, VIRT_UART0_RxCpltCallback) != VIRT_UART_OK)
    {
  	  Error_Handler();
    }
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
   while (1){
	  	 OPENAMP_check_for_message();

	  	 ds18b20_search_rom();
	  	 /*
	  	 printf("DS18B20_SensorNum=%d \r\n",DS18B20_SensorNum);
	  	 for(i=0;i<DS18B20_SensorNum;i++){
	  			  printf("id%d:",i);
	  			  for(j=0;j<8;j++){
	  				  printf("%02x",DS18B20_ID[state][j]);
	  			  }

	  			  printf(" ");
	  			  temperature=ds18b20_get_temp_id((uint8_t *)DS18B20_ID[state]);
	  			  printf("TEM:%.2f\r\n",temperature);

	  			  delay_ms(500);
	  	 }

	  	  */

	  	 /*
	  	sprintf((char *)BuffTx,"I");
	  	VIRT_UART_Transmit(&huart0, BuffTx, strlen((const char *)BuffTx));
	  	memset(BuffTx, 0, sizeof(BuffTx));

	  	delay_ms(1);

	  	printf("id%d:",state);
	  	for(j=0;j<8;j++){
	  		printf("%02x",DS18B20_ID[state][j]);
	  	}
	  	printf("\r\n");

	  	for(j=0;j<8;j++){
	  		sprintf((char *)BuffTx,"%02x",DS18B20_ID[state][j]);
	  		VIRT_UART_Transmit(&huart0, BuffTx, strlen((const char *)BuffTx));
	  		memset(BuffTx, 0, sizeof(BuffTx));
	  	}

	  	delay_ms(1);

	  	sprintf((char *)BuffTx,"T");
	  	VIRT_UART_Transmit(&huart0, BuffTx, strlen((const char *)BuffTx));
	  	memset(BuffTx, 0, sizeof(BuffTx));

	  	delay_ms(1);

	  	temperature=ds18b20_get_temp_id((uint8_t *)DS18B20_ID[state]);
	  	printf("TEM:%.2f\r\n",temperature);
	  	sprintf((char *)BuffTx,"%.2f",temperature);
	  	VIRT_UART_Transmit(&huart0, BuffTx, strlen((const char *)BuffTx));
	  	memset(BuffTx, 0, sizeof(BuffTx));
*/


		sprintf((char *)buf,"%02x%02X%02X%02X%02x%02X%02X%02X",DS18B20_ID[state][0],DS18B20_ID[state][1],DS18B20_ID[state][2],DS18B20_ID[state][3],DS18B20_ID[state][4],DS18B20_ID[state][5],DS18B20_ID[state][6],DS18B20_ID[state][7]);
	  	cjson_head=cJSON_CreateObject();
	  	//printf("%s\r\n",BuffTx);
	  	temperature=ds18b20_get_temp_id((uint8_t *)DS18B20_ID[state]);
	  	cjson_temp = cJSON_CreateObject();
	  	cJSON_AddNumberToObject(cjson_temp, "T",temperature);
	  	cJSON_AddNumberToObject(cjson_temp, "N", DS18B20_SensorNum);
	  	cJSON_AddStringToObject(cjson_temp, "I", buf);
	  	cJSON_AddItemToObject(cjson_head, "temp", cjson_temp);

	  	memset(BuffTx, 0, sizeof(BuffTx));

	  	str = cJSON_Print(cjson_head);
	  	printf("%s\n", str);
	  	sprintf((char *)BuffTx,"%s",str);
	  	VIRT_UART_Transmit(&huart0, BuffTx, strlen((const char *)BuffTx));
	  	memset(BuffTx, 0, sizeof(BuffTx));

	  	delay_ms(100);

   }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.HSIDivValue = RCC_HSI_DIV1;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  RCC_OscInitStruct.PLL2.PLLState = RCC_PLL_NONE;
  RCC_OscInitStruct.PLL3.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL3.PLLSource = RCC_PLL3SOURCE_HSI;
  RCC_OscInitStruct.PLL3.PLLM = 4;
  RCC_OscInitStruct.PLL3.PLLN = 26;
  RCC_OscInitStruct.PLL3.PLLP = 2;
  RCC_OscInitStruct.PLL3.PLLQ = 2;
  RCC_OscInitStruct.PLL3.PLLR = 2;
  RCC_OscInitStruct.PLL3.PLLRGE = RCC_PLL3IFRANGE_1;
  RCC_OscInitStruct.PLL3.PLLFRACV = 1024;
  RCC_OscInitStruct.PLL3.PLLMODE = RCC_PLL_FRACTIONAL;
  RCC_OscInitStruct.PLL4.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** RCC Clock Config
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_ACLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_PCLK3|RCC_CLOCKTYPE_PCLK4
                              |RCC_CLOCKTYPE_PCLK5;
  RCC_ClkInitStruct.AXISSInit.AXI_Clock = RCC_AXISSOURCE_HSI;
  RCC_ClkInitStruct.AXISSInit.AXI_Div = RCC_AXI_DIV1;
  RCC_ClkInitStruct.MCUInit.MCU_Clock = RCC_MCUSSOURCE_PLL3;
  RCC_ClkInitStruct.MCUInit.MCU_Div = RCC_MCU_DIV1;
  RCC_ClkInitStruct.APB4_Div = RCC_APB4_DIV1;
  RCC_ClkInitStruct.APB5_Div = RCC_APB5_DIV1;
  RCC_ClkInitStruct.APB1_Div = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2_Div = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB3_Div = RCC_APB3_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Set the HSE division factor for RTC clock
  */
  __HAL_RCC_RTC_HSEDIV(1);
}

/**
  * @brief Peripherals Common Clock Configuration
  * @retval None
  */
void PeriphCommonClock_Config(void)
{
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the common periph clock
  */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_CKPER;
  PeriphClkInit.CkperClockSelection = RCC_CKPERCLKSOURCE_HSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void VIRT_UART0_RxCpltCallback(VIRT_UART_HandleTypeDef *huart)
{

    printf("\n\rReceived on Virtual UART0:\n\r%s\n\rSize:%d\n\r", (char *) huart->pRxBuffPtr,huart->RxXferSize);
    flag = SET;
    OPENAMP_check_for_message();

    if(*((char *)huart->pRxBuffPtr)='000'){
    	ds18b20_search_rom();
/*
    	sprintf((char *)BuffTx,"N");
    	VIRT_UART_Transmit(&huart0, BuffTx, strlen((const char *)BuffTx));
    	memset(BuffTx, 0, sizeof(BuffTx));

    	delay_ms(500);

    	printf("DS18B20_SensorNum=%d \r\n",DS18B20_SensorNum);
	  	sprintf((char *)BuffTx,"%d",DS18B20_SensorNum);
	  	VIRT_UART_Transmit(&huart0, BuffTx, strlen((const char *)BuffTx));
	  	memset(BuffTx, 0, sizeof(BuffTx));
*/
    }

    if(*((char *)huart->pRxBuffPtr)='001'){
        if(state<DS18B20_SensorNum-1){
        	state++;
        }
        else{
        	state=0;
        }
    }

}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
